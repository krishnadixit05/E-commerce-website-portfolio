// Add any interactivity here if needed
console.log("Portfolio Loaded Successfully");
